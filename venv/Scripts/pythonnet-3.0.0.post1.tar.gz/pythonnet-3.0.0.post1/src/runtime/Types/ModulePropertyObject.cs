using System;
using System.Reflection;

namespace Python.Runtime
{
    /// <summary>
    /// Module level properties (attributes)
    /// </summary>
    internal class ModulePropertyObject : ExtensionType
    {
        public ModulePropertyObject(PropertyInfo md)
        {
            throw new NotImplementedException("ModulePropertyObject");
        }
    }
}
