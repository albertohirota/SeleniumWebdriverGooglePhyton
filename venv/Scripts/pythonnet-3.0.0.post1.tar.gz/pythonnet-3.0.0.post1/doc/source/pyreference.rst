Python Reference
================

Runtime loading and configuration
---------------------------------

.. automodule:: pythonnet
   :members:


