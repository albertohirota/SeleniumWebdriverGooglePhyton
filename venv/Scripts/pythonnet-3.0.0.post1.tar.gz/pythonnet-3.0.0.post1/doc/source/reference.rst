C# Reference
------------

..
    .. doxygennamespace:: Python::Runtime
       :members:
       :outline:

.. doxygenclass:: Py
   :members:

.. doxygenclass:: Python::Runtime::PythonEngine
   :members:
.. doxygenclass:: Python::Runtime::PyObject
   :members:

.. doxygenclass:: Python::Runtime::PyDict
   :members:
.. doxygenclass:: Python::Runtime::PyTuple
   :members:
.. doxygenclass:: Python::Runtime::PyList
   :members:
.. doxygenclass:: Python::Runtime::PyInt
   :members:
.. doxygenclass:: Python::Runtime::PyString
   :members:
.. doxygenclass:: Python::Runtime::PyType
   :members:
.. doxygenclass:: Python::Runtime::PyModule
   :members:
.. doxygenclass:: Python::Runtime::PyIter
   :members:

.. doxygenclass:: Python::Runtime::PyBuffer
   :members:
.. doxygenenum:: Python::Runtime::BufferOrderStyle
.. doxygenclass:: Python::Runtime::PyIterable
   :members:
.. doxygenclass:: Python::Runtime::PySequence
   :members:
.. doxygenclass:: Python::Runtime::PyNumber
   :members:
