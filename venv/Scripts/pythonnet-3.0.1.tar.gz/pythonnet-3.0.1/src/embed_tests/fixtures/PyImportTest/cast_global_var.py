# -*- coding: utf-8 -*-

FOO = 1


def test_foo():
    return FOO
