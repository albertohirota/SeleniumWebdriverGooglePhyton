namespace Python.Runtime.Native;

/// <remarks><c>PyGILState_STATE</c></remarks>
enum PyGILState
{
    PyGILState_LOCKED,
    PyGILState_UNLOCKED 
}
