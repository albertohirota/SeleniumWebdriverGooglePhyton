namespace Python.Runtime.Native;

/// <summary>Catch-all type for native function objects (to be pointed to)</summary>
struct NativeFunc
{
}
